#pragma once
#include "SimpleAnimatedSprite.hpp"
#include "Game.hpp"

namespace terr {
	class Sheep :
		public SimpleAnimatedSprite
	{
	};
}