#include "Game.hpp"

int main(int t_argc, char* t_argv[])
{
	terr::Game game;
	game.start();

	return 0;
}
